<template>
  <h1>This is About page.</h1>
  <router-link to="/">Home</router-link> |
  <router-link to="/about">About</router-link>
</template>

<script>
export default {
}
</script>

<style scoped>
</style>
